## Electrical Contractor CRM — Build Plan

A bilingual-ready (Italian-first UI) CRM for a small Italian electrical contracting business, built on TanStack Start + Lovable Cloud (Supabase) with role-based access.

### Stack & foundations
- TanStack Start (existing template), Tailwind v4, shadcn/ui
- Lovable Cloud for Postgres, Auth (email/password), Storage (bolle, schemi planimetrici, PDFs), Storage policies
- All UI copy in Italian; clean, utilitarian design (neutral palette, generous spacing, table-dense admin views, large-tap contractor view)
- PDF generation via `pdf-lib` (invoices + DICO drafts), printable HTML fallback

### Phase 1 — Backend (single migration)
Schema exactly as specified, plus:
- `app_role` enum (`admin`, `contractor`)
- `user_roles` table + `has_role()` security-definer function (no roles on profiles)
- `profiles` table linked to `auth.users` (name, contractor_id link)
- `company_settings` singleton table (legal info reused on invoices + DICO)
- All tables: GRANTs + RLS
  - Admin: full access via `has_role(auth.uid(),'admin')`
  - Contractor: read/write only their own `logged_hours` (matched via `profiles.contractor_id`); no other table access
- Storage buckets: `bolle` (private), `invoices` (private), `dico` (private), `schemi` (private)
- Trigger: auto-create profile on signup

### Phase 2 — Auth & routing
- `/auth` public page (login/signup)
- `_authenticated` layout (integration-managed) gates everything else
- Role router: after login, admin → `/dashboard`, contractor → `/ore` (hour logging)
- A `_admin` pathless layout that checks `has_role` server-side and redirects contractors away

### Phase 3 — Admin app
Sidebar shell with these routes:
1. `/dashboard` — KPI cards: lavori attivi, ore da approvare (mese), acquisti recenti, fatture in bozza
2. `/clienti` — list + search; `/clienti/$id` detail (jobs, totale fatturato, contatti); create/edit form with P.IVA + CF
3. `/lavori` — list filterable by stato + cliente; `/lavori/$id` detail with tabs (Ore, Acquisti, Totali) + "Genera Fattura" + "Genera Bozza DICO"
4. `/contractors` — list with hourly_rate; detail with monthly stats; add/edit
5. `/ore/approvazione` — submitted-unapproved grouped by contractor + month; bulk approve; client-missing flag highlighted with reassign-to-job action
6. `/grossisti` — wholesalers CRUD
7. `/acquisti` — list filterable by wholesaler/job/date; `/acquisti/nuovo` import flow:
   - Upload bolla (PDF/Excel) → choose wholesaler → server fn dispatches to parser by `system_type`
   - Two parsers scaffolded (`parserA`, `parserB`) behind a registry so adding a third is just a new file
   - Parsed rows shown in editable table → confirm → insert
   - Manual reassign-to-job action on any purchase
8. `/fatture` — list; generation wizard from job detail:
   - Aggregates approved hours × rate (labor), purchase line items (materials)
   - Prompt markup % → compute totals → preview → save draft → PDF
   - Status: bozza/inviata/pagata; `sdi_xml_url` left empty (future)
9. `/dico` — draft generator from job:
   - Pre-fills installer info from `company_settings`, client info from job
   - Intervention type dropdown (nuovo impianto / trasformazione / ampliamento / manutenzione straordinaria)
   - Materials report auto-built from job's purchase line items
   - Visually distinct placeholders for schema planimetrico (upload), RT signature, timbro
   - Prominent legal disclaimer banner (exact Italian copy from spec)
   - Export PDF
10. `/impostazioni` — company info + wholesaler management

### Phase 4 — Contractor app
- `/ore` — mobile-first form: job selector OR "cliente mancante" toggle with free-text note, date, hours, description
- `/ore/storico` — monthly view of own entries with submission/approval status, "Invia il mese" button (locks entries, sets `submitted=true`, `submitted_at=now()`)

### Phase 5 — PDF generation
- Server functions using `pdf-lib`:
  - `generateInvoicePdf(invoiceId)` — clean Italian fattura layout, uploads to `invoices` bucket, stores signed URL
  - `generateDicoDraftPdf(dicoId)` — DICO bozza with disclaimer, materials table, blank signature/stamp blocks

### Technical notes
- Server fns in `src/lib/*.functions.ts`, authenticated via `requireSupabaseAuth`; admin checks via `has_role` RPC inside handlers
- Bolla parsers in `src/lib/parsers/` with a registry keyed by `wholesalers.system_type` — Excel via `xlsx` lib, PDF via `pdf-parse` (text extraction). Both parsers return a normalized line-item array; UI lets admin correct before save.
- TanStack Query for all data fetching; loaders prime cache; mutations invalidate keys
- Italian labels throughout; date formatting via `Intl` with `it-IT`
- Numbers formatted as EUR with `Intl.NumberFormat('it-IT', {style:'currency',currency:'EUR'})`

### Out of scope (per spec)
- Actual SDI XML generation/submission
- Legal validation or submission of DICO
- Email notifications (admin "notified" on submission = dashboard surface only)

### Build order
1. Enable Lovable Cloud + run schema migration with RLS/grants
2. Auth + role routing + shells
3. Settings, clients, contractors, jobs (CRUD foundation)
4. Hour logging (contractor) + approval (admin)
5. Wholesalers + purchase import with two parsers
6. Invoice generation + PDF
7. DICO draft + PDF
8. Dashboard wiring
